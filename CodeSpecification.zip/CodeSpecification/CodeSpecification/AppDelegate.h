//
//  AppDelegate.h
//  CodeSpecification
//
//  Created by 王方 on 16/6/1.
//  Copyright © 2016年 http://blog.sina.com.cn/wangfangcode All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

