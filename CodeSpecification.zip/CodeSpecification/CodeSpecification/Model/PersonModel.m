//
//  PersonModel.m
//  CodeSpecification
//
//  Created by 王方 on 16/8/13.
//  Copyright © 2016年 http://www.jianshu.com/users/db5d90611afa/latest_articles All rights reserved.
//

#import "PersonModel.h"

@implementation PersonModel

@end
