//
//  Literals.h
//  CodeSpecification
//
//  Created by 王方 on 16/8/13.
//  Copyright © 2016年 http://www.jianshu.com/users/db5d90611afa/latest_articles. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  集合/字典 规范
 */
@interface Literals : UIViewController

- (void)arraySpecification;

- (void)dictionarySpecification;

- (void)numberSpecification;

@end
