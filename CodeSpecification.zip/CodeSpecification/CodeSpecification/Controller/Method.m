//
//  Method.m
//  CodeSpecification
//
//  Created by 王方 on 16/8/13.
//  Copyright © 2016年 http://www.jianshu.com/users/db5d90611afa/latest_articles. All rights reserved.
//

#import "Method.h"

@interface Method ()

@end

@implementation Method

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)loginWithUserName:(NSString *)userName passowrd:(NSString *)password {}
+ (void)loginWithUserName:(NSString *)userName passowrd:(NSString *)password {}

@end
